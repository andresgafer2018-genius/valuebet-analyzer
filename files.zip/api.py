"""
API REST — Flask Backend
=========================
Endpoints:
  GET /api/alerts          → value bets del día
  GET /api/predictions     → predicciones con probabilidades
  GET /api/bankroll        → resumen de gestión de bankroll
  GET /api/health          → status del sistema
"""

import sys
import json
from pathlib import Path
from flask import Flask, jsonify, request
from flask_cors import CORS

sys.path.insert(0, str(Path(__file__).parent.parent))

from data.fetcher import DataFetcher
from models.engine import PoissonModel, LogisticModel, ValueBetDetector
from analysis.pipeline import train_models

app = Flask(__name__)
CORS(app)

# Cache en memoria (en producción: Redis)
_cache = {"alerts": None, "predictions": None, "bankroll": 1000.0}

def _ensure_loaded():
    if _cache["alerts"] is None:
        fetcher = DataFetcher()
        poisson_model, logistic_model = train_models(fetcher, n=300)
        detector = ValueBetDetector()
        upcoming = fetcher.get_upcoming_matches()
        all_alerts, all_preds = [], []

        for match in upcoming:
            pred = poisson_model.predict_proba(
                match["home_team"], match["away_team"], match["league"]
            )
            odds = fetcher.get_simulated_odds(match)
            alerts = detector.detect(pred, odds, match)
            all_alerts.extend(alerts)
            all_preds.append({**match, **pred})

        seen = {}
        for a in sorted(all_alerts, key=lambda x: x["edge_pct"], reverse=True):
            k = f"{a['match_id']}_{a['market']}"
            if k not in seen:
                seen[k] = a

        _cache["alerts"] = sorted(seen.values(), key=lambda x: x["edge_pct"], reverse=True)
        _cache["predictions"] = all_preds


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "model": "poisson+logistic", "version": "1.0.0"})


@app.route("/api/alerts")
def get_alerts():
    _ensure_loaded()
    league   = request.args.get("league")
    min_edge = float(request.args.get("min_edge", 3.0))
    conf     = request.args.get("confidence")

    alerts = _cache["alerts"]
    if league:
        alerts = [a for a in alerts if a["league"].lower() == league.lower()]
    if conf:
        alerts = [a for a in alerts if a["confidence"] == conf.upper()]
    alerts = [a for a in alerts if a["edge_pct"] >= min_edge]

    return jsonify({"count": len(alerts), "alerts": alerts})


@app.route("/api/predictions")
def get_predictions():
    _ensure_loaded()
    league = request.args.get("league")
    preds  = _cache["predictions"]
    if league:
        preds = [p for p in preds if p["league"].lower() == league.lower()]
    return jsonify({"count": len(preds), "predictions": preds})


@app.route("/api/bankroll", methods=["GET", "POST"])
def bankroll():
    if request.method == "POST":
        data = request.get_json()
        _cache["bankroll"] = float(data.get("bankroll", 1000.0))
    _ensure_loaded()
    alerts      = _cache["alerts"]
    bk          = _cache["bankroll"]
    total_kelly = sum(a["kelly_frac"] for a in alerts[:10])
    exposure    = min(total_kelly, 0.20) * bk
    return jsonify({
        "bankroll":          bk,
        "suggested_exposure": round(exposure, 2),
        "max_exposure_pct":  20.0,
        "active_alerts":     len(alerts),
        "avg_kelly":         round(total_kelly / max(len(alerts), 1) * 100, 2),
    })


@app.route("/api/refresh", methods=["POST"])
def refresh():
    _cache["alerts"]      = None
    _cache["predictions"] = None
    return jsonify({"status": "cache cleared, will reload on next request"})


if __name__ == "__main__":
    print("[API] Iniciando servidor en http://localhost:5050")
    app.run(port=5050, debug=False)
